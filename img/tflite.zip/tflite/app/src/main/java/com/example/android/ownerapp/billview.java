package com.example.android.ownerapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.android.ownerapp.initialization.Setup;
import com.example.android.ownerapp.stock_management.Add_IR_Barcode;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static com.example.android.ownerapp.FirebaseSupportClass.IRsnap;

public class billview extends AppCompatActivity {
    TableLayout bill_ID_TL, bill_ITEM_TL;
    Map<String, Map<String,String>> billmap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_billview);
        createtoprow();
        bill_ID_TL = findViewById(R.id.bill_ID_TL);
        bill_ITEM_TL = findViewById(R.id.bill_ITEMS_TL);
        ((CalendarView) findViewById(R.id.calendarView))
                .setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {

                        String selectedDate = "" + ((i2 < 10) ? "0" + i2 : i2) + "-" + (((i1 + 1) < 10) ? "0" + (i1 + 1) : (i1 + 1)) + "-" + i;

                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference(Setup.uid+"/BILLS/" + selectedDate);
                        myRef.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                billmap.clear();
                                bill_ID_TL.removeAllViews();
                                bill_ITEM_TL.removeAllViews();
                                TableRow r0= new TableRow(billview.this);
                                TextView Tv0=new TextView(billview.this);
                                Tv0.setText("SALES HISTORY("+selectedDate+")");
                                r0.addView(Tv0);
                                bill_ITEM_TL.addView(r0);
                                bill_ITEM_TL.addView(r1);

                                TableRow.LayoutParams params2 = (TableRow.LayoutParams) Tv0.getLayoutParams();
                                params2.span = 4; //amount of columns you will span
                                Tv0.setLayoutParams(params2);

                                // ((TextView)findViewById(R.id.headingforitems)).setText("REPORT("+selectedDate+")");
                                double totalsales = 0.0, totaldiscount = 0.0;
                                for (DataSnapshot eachdevice : dataSnapshot.getChildren()) {

                                    for (DataSnapshot eachbill : eachdevice.getChildren()) {
                                        double total = 0.0;
                                        for (DataSnapshot eachitem : eachbill.getChildren()) {
                                            if (eachitem.child("DELETED").exists()) continue;
                                            String itemkeyformap = eachitem.child("DB_NAME").getValue().toString() +
                                                    "*" + eachitem.child("NAME").getValue().toString()
                                                    + "@" + eachitem.child("PRICE").getValue().toString();
                                            if (billmap.containsKey(itemkeyformap)) {
                                                //update to the existing value with quantity and amount
                                                /*
                                                billmap format
                                                key =DB_NAME*NAME@PRICE
                                                value = DB_NAME
                                                        FIREBASE_PATH
                                                        NAME
                                                        QUANTITY
                                                        TOTAL
                                                 */

                                                Map<String,String> value = billmap.get(itemkeyformap);

                                                Float QUANTITY = Float.parseFloat(value.get("QUANTITY"));
                                                Float TOTAL = Float.parseFloat(value.get("TOTAL"));
                                                QUANTITY += Float.parseFloat(eachitem.child("QUANTITY").getValue().toString());
                                                TOTAL += Float.parseFloat(eachitem.child("TOTAL").getValue().toString());
                                                value.put("QUANTITY",""+QUANTITY);
                                                value.put("TOTAL",""+TOTAL);
                                                billmap.put(itemkeyformap, value);
                                            } else {
                                                Map<String,String> value = new HashMap<>();
                                                value.put("DB_NAME",eachitem.child("DB_NAME").getValue().toString());
                                                value.put("FIREBASE_PATH",eachitem.child("FIREBASE_PATH").getValue().toString());
                                                value.put("QUANTITY",eachitem.child("QUANTITY").getValue().toString());
                                                value.put("TOTAL",eachitem.child("TOTAL").getValue().toString());
                                                billmap.put(itemkeyformap, value);
                                            }


                                            if (eachitem.child("NAME").getValue().toString().equals("DISCOUNT")) {
                                                totaldiscount += Float.parseFloat(eachitem.child("TOTAL").getValue().toString());
                                            }
                                            total += Float.parseFloat(eachitem.child("TOTAL").getValue().toString());
                                        }
                                        totalsales += total;

                                        TableRow tbrow = new TableRow(billview.this);
                                        Button button = new Button(billview.this);
                                        String billid = eachbill.getKey();

                                        button.setText(billid.substring(0, billid.lastIndexOf("C"))
                                                + "\n (" + round(total, 2) + ")");
                                        tbrow.addView(button);
                                        button.setTag(R.id.BILLDBKEY, eachbill);
                                        button.setOnClickListener(billview.this::showbill);
                                        bill_ID_TL.addView(tbrow);
                                    }

                                }

                                {
                                    Iterator iterator = billmap.keySet().iterator();
                                    while (iterator.hasNext()) {
                                        String key = iterator.next().toString();
                                        Map<String, String> value = billmap.get(key);
                                        TableRow reportrow = new TableRow(billview.this);
                                        TextView pathtv = new TextView(billview.this);
                                        TextView pricetv = new TextView(billview.this);
                                        TextView quantitytv = new TextView(billview.this);
                                        TextView totaltv = new TextView(billview.this);
                                        Button barcode_button = new Button(billview.this);
                                        String NAME = key.substring((key.indexOf("*") + 1), key.indexOf("@"));
                                        String PRICE = key.substring(key.indexOf("@") + 1);



                                        String QUANTITY = value.get("QUANTITY");
                                        String TOTAL = value.get("TOTAL");
                                        pathtv.setText(NAME  );
                                        pricetv.setText(PRICE  );
                                        quantitytv.setText(QUANTITY  );
                                        totaltv.setText(TOTAL  );
                                        reportrow.addView(pathtv);
                                        reportrow.addView(pricetv);
                                        reportrow.addView(quantitytv);
                                        reportrow.addView(totaltv);
                                        if(value.get("DB_NAME").equals("BARCODE")){
                                            barcode_button.setText(value.get("FIREBASE_PATH"));
                                            reportrow.addView(barcode_button);
                                            barcode_button.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {


                                                    String v= value.get("FIREBASE_PATH");
                                                    Intent i = new Intent(billview.this, Add_IR_Barcode.class);
                                                    i.putExtra("BARCODE",v);
                                                    startActivity(i);
                                                }
                                            });

                                        }

                                        bill_ITEM_TL.addView(reportrow);

                                        TableRow.LayoutParams params1 = (TableRow.LayoutParams) pathtv.getLayoutParams();
                                        params1.width = 200;
                                        pathtv.setLayoutParams(params1);
                                        pathtv.setTextColor(Color.parseColor("#0000ff"));
                                        pricetv.setTextColor(Color.parseColor("#800080"));
                                        quantitytv.setTextColor(Color.parseColor("#008000"));
                                        totaltv.setTextColor(Color.parseColor("#ff0000"));
                                    }
                                }

                                TableRow tbrow = new TableRow(billview.this);
                                Button button = new Button(billview.this);
                                button.setText("REPORT\nSales = " +
                                        (round(totalsales, 2) + (-1 * round(totaldiscount, 2))) +
                                        "\nDiscount =" +
                                        round(totaldiscount, 2) + "\n" +
                                        "Collection = " + round(totalsales, 2));
                                tbrow.addView(button);
                                bill_ITEM_TL.addView(tbrow,1);
                                TableRow.LayoutParams params = (TableRow.LayoutParams) button.getLayoutParams();
                                params.span = 4; //amount of columns you will span
                                button.setLayoutParams(params);

                                // billmap itrator

                            }

                            @Override
                            public void onCancelled(DatabaseError error) {
                            }
                        });

                    }
                });
    }

    private void createtoprow() {
        r1 = new TableRow(billview.this);
        TextView a1 = new TextView(billview.this);
        TextView a2 = new TextView(billview.this);
        TextView a3 = new TextView(billview.this);
        TextView a4 = new TextView(billview.this);
        a1.setText("NAME");
        a2.setText("PRICE ");
        a3.setText("QUANTITY ");
        a4.setText("TOTAL");
        a1.setTextColor(Color.parseColor("#ff8c00"));
        a2.setTextColor(Color.parseColor("#ff8c00"));
        a3.setTextColor(Color.parseColor("#ff8c00"));
        a4.setTextColor(Color.parseColor("#ff8c00"));
        a1.setTypeface(null, Typeface.BOLD);
        a2.setTypeface(null, Typeface.BOLD);
        a3.setTypeface(null, Typeface.BOLD);
        a4.setTypeface(null, Typeface.BOLD);
        r1.addView(a1);
        r1.addView(a2);
        r1.addView(a3);
        r1.addView(a4);
    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    public void showbill(View view) {
        // ((TextView)findViewById(R.id.headingforitems)).setText(((Button)view).getText().toString());
        bill_ITEM_TL.removeAllViews();
        DataSnapshot selectedBillSS = (DataSnapshot) view.getTag(R.id.BILLDBKEY);

        for (DataSnapshot eachitem : selectedBillSS.getChildren()) {
            if (eachitem.child("DELETED").exists()) {
                continue;
            }
            // total+=Float.parseFloat(eachitem.child("TOTAL").getValue().toString());
            TableRow tbrow = new TableRow(billview.this);
            Button button = new Button(billview.this);
            String name = eachitem.child("NAME").getValue().toString();
            String price = eachitem.child("PRICE").getValue().toString();
            String quantity = eachitem.child("QUANTITY").getValue().toString();
            String total = eachitem.child("TOTAL").getValue().toString();
            button.setText(name + "\n" + price + " X " + quantity + " = " + total);
            tbrow.addView(button);
            bill_ITEM_TL.addView(tbrow);
        }

    }
TableRow r1;
    public void checkboxupdate(View view) {
        bill_ITEM_TL.removeAllViews();
        bill_ITEM_TL.addView(r1);
        double totalsales = 0.0, totaldiscount = 0.0;
        {
            Iterator iterator = billmap.keySet().iterator();
            while (iterator.hasNext()) {
                String key = iterator.next().toString();
                Map<String, String> value = billmap.get(key);
                TableRow reportrow = new TableRow(billview.this);
                TextView pathtv = new TextView(billview.this);
                TextView pricetv = new TextView(billview.this);
                TextView quantitytv = new TextView(billview.this);
                TextView totaltv = new TextView(billview.this);
                boolean ir=((CheckBox) findViewById(R.id.IR)).isChecked();
                boolean bcd=((CheckBox) findViewById(R.id.BARCODE)).isChecked();
                //both not checked
                if(!ir && !bcd) if (key.contains("IR*") || key.contains("BARCODE*"))continue;

                if(!bcd && ir && !key.contains("IR*"))continue;

                if(bcd && !ir && !key.contains("BARCODE*"))continue;



                String Name = key.substring((key.indexOf("*") + 1), key.indexOf("@"));
                String Price = key.substring(key.indexOf("@") + 1);
                String QUANTITY =value.get("QUANTITY");
                String TOTAL = value.get("TOTAL");

                if(Name.equals("DISCOUNT")) {
                    totaldiscount += Float.parseFloat(TOTAL);
                }
                totalsales += Float.parseFloat(TOTAL);

                pathtv.setText(Name  );
                pricetv.setText(Price  );
                quantitytv.setText(QUANTITY  );
                totaltv.setText(TOTAL );
                reportrow.addView(pathtv);
                reportrow.addView(pricetv);
                reportrow.addView(quantitytv);
                reportrow.addView(totaltv);
                bill_ITEM_TL.addView(reportrow);
                TableRow.LayoutParams params = (TableRow.LayoutParams) pathtv.getLayoutParams();
                params.width = 200;
                pathtv.setLayoutParams(params);
                pathtv.setTextColor(Color.parseColor("#0000ff"));
                pricetv.setTextColor(Color.parseColor("#800080"));
                quantitytv.setTextColor(Color.parseColor("#008000"));
                totaltv.setTextColor(Color.parseColor("#ff0000"));
            }

            TableRow tbrow = new TableRow(billview.this);
            Button button = new Button(billview.this);
            button.setText("REPORT\nSales = " +
                    (round(totalsales, 2) + (-1 * round(totaldiscount, 2))) +
                    "\nDiscount =" +
                    round(totaldiscount, 2) + "\n" +
                    "Collection = " + round(totalsales, 2));
            tbrow.addView(button);
            bill_ITEM_TL.addView(tbrow,1);
            TableRow.LayoutParams params = (TableRow.LayoutParams) button.getLayoutParams();
            params.span = 4; //amount of columns you will span
            button.setLayoutParams(params);


        }
    }


}