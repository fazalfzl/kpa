package com.example.android.ownerapp.initialization;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.android.ownerapp.R;
 import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import static com.example.android.ownerapp.Support_Functions.windowRelatedActions;

public class login extends AppCompatActivity {
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        windowRelatedActions(this);
        setContentView(R.layout.activity_login);


        if (savedInstanceState == null) {

            FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        }
        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            ((EditText) findViewById(R.id.editTextTextEmailAddress)).setText("");
            ((EditText) findViewById(R.id.editTextTextPassword)).setText("");
            Intent intent = new Intent(login.this, Setup.class);
            startActivity(intent);
        }
    }

    public void login(View view) {
        String email = ((EditText) findViewById(R.id.editTextTextEmailAddress)).getText().toString();
        String password = ((EditText) findViewById(R.id.editTextTextPassword)).getText().toString();
        if (((Button) view).getText().toString().contains("LOGIN")) {
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                FirebaseUser user = mAuth.getCurrentUser();
                                ((EditText) findViewById(R.id.editTextTextEmailAddress)).setText("");
                                ((EditText) findViewById(R.id.editTextTextPassword)).setText("");
                                Intent intent = new Intent(login.this, Setup.class);
                                startActivity(intent);
                            } else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(login.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();
                            }

                            // ...
                        }
                    });
        } else {
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                FirebaseUser user = mAuth.getCurrentUser();
                                ((EditText) findViewById(R.id.editTextTextEmailAddress)).setText("");
                                ((EditText) findViewById(R.id.editTextTextPassword)).setText("");
                                Intent intent = new Intent(login.this, Setup.class);
                                startActivity(intent);
                            } else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(login.this, "Authentication failed."+task.getException().toString(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }


    }

    public void newregistration(View view) {

        if (((Button) view).getText().toString().equals("NEW REGISTRATION")) {
            ((Button) view).setText("ALREADY REGISTERD?");
            ((Button) findViewById(R.id.button)).setText("REGISTER");
        } else {
            ((Button) view).setText("NEW REGISTRATION");
            ((Button) findViewById(R.id.button)).setText("LOGIN");
        }

    }
}