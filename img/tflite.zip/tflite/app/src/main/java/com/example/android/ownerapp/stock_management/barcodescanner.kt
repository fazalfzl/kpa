package com.example.android.ownerapp.stock_management

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.android.ownerapp.R
import com.example.android.ownerapp.Support_Functions
import kotlinx.android.synthetic.main.activity_add__i_r__barcode.*
import kotlinx.android.synthetic.main.activity_barcodescanner.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class barcodescanner : AppCompatActivity() {

    private var processingBarcode = AtomicBoolean(false)
    private lateinit var cameraExecutor: ExecutorService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_barcodescanner)

        cameraExecutor = Executors.newSingleThreadExecutor()
        startCamera()
    }


    private fun startCamera() {

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({

            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                    .build().also {
                        it.setSurfaceProvider(
                                fragment_scan_barcode_preview_view.surfaceProvider
                        )
                    }
            // Setup the ImageAnalyzer for the ImageAnalysis use case
            val imageAnalysis = ImageAnalysis.Builder()
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor, BarcodeAnalyzer { barcode: String ->
                            if (processingBarcode.compareAndSet(false, true)) {
                                // searchBarcode(barcode) result in barcode
                                Toast.makeText(this, "yse$barcode", Toast.LENGTH_SHORT).show()
                                Support_Functions.barcode=barcode
                                val v: String = barcode
                                val i = Intent(this, Add_IR_Barcode::class.java)
                                i.putExtra("BARCODE", v)
                                startActivity(i)
                                //  startCamera()
                            }
                        })
                    }

            // Select back camera
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            try {
                // Unbind any bound use cases before rebinding
                cameraProvider.unbindAll()
                // Bind use cases to lifecycleOwner
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis)
            } catch (e: Exception) {
                Log.e("PreviewUseCase", "Binding failed! :(", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun allPermissionsGranted() = barcodescanner.REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(this, it
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray)
    {
        if (requestCode == barcodescanner.REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this,
                        "Permissions not granted by the user.",
                        Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onDestroy() {
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }
}
typealias BarcodeListener = (barcode: String) -> Unit