package com.example.android.ownerapp.stock_management

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.android.ownerapp.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_add__i_r__barcode.*
import java.util.*


class Add_IR_Barcode : AppCompatActivity() {
    var sadapter1: FilterWithSpaceAdapter<String>? = null
    var sadapter2: FilterWithSpaceAdapter<String>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Support_Functions.windowRelatedActions(this)
        setContentView(R.layout.activity_add__i_r__barcode)


        setupUI(findViewById(R.id.rlll))
        sadapter1 = FilterWithSpaceAdapter<String>(this,
                R.layout.item_layout,R.id.tvresid, Support_Functions.barcodeList)

        autoCompleteTextView.threshold = 1
        autoCompleteTextView.setAdapter(sadapter1) //setting the adapter data into the AutoCompleteTextView
        autoCompleteTextView.setTextColor(Color.RED)

        sadapter2 = FilterWithSpaceAdapter<String>(this,
                R.layout.item_layout,R.id.tvresid, Support_Functions.generatedSupplyerList)
        SUPPLIERID.threshold = 1
        SUPPLIERID.setAdapter(sadapter2) //setting the adapter data into the AutoCompleteTextView
        SUPPLIERID.setTextColor(Color.RED)

        autoCompleteTextView.onItemClickListener = OnItemClickListener { parent: AdapterView<*>?, arg1: View?, pos: Int, id: Long ->
            //  Toast.makeText(check.this," selected", Toast.LENGTH_LONG).show();
            enterbutton(autoCompleteTextView)
        }
        SUPPLIERID.onItemClickListener = OnItemClickListener { parent: AdapterView<*>?, arg1: View?, pos: Int, id: Long ->
            //  Toast.makeText(check.this," selected", Toast.LENGTH_LONG).show();
            enterbuttonsupplyer(SUPPLIERID)
        }
    }

    override fun onResume() {
        super.onResume()
        if(Support_Functions.barcode!=null && !Support_Functions.barcode.equals("")){
            autoCompleteTextView.setText(Support_Functions.barcode)
            enterbutton(autoCompleteTextView)
            Support_Functions.barcode=""
        }

        val extras = intent.extras
        if (extras != null) {
            val BARCODE = extras.getString("BARCODE")
            autoCompleteTextView.setText(BARCODE)
            enterbutton(autoCompleteTextView)
        }
    }

    private fun barcode_scaned(scanned_barcode: String) {
        if (FirebaseSupportClass.BCDsnap.child(scanned_barcode).exists()) {
            val bcdsnap = FirebaseSupportClass.BCDsnap.child(scanned_barcode)
            val type = bcdsnap.child("UNIT").value.toString()
            NAME.setText(bcdsnap.child("NAME").value.toString())
            if (type == "weight") {
                rb1.isChecked = true
            } else rb2.isChecked = true
            STOCK.setText(bcdsnap.child("STOCK").value.toString())
            SALES_RATE.setText(bcdsnap.child("SALES_RATE").value.toString())
            MRP.setText(bcdsnap.child("MRP").value.toString())
            PURCHASE_RATE.setText(bcdsnap.child("PURCHASE_RATE").value.toString())
            GST.setText(bcdsnap.child("GST").value.toString())
            CESS.setText(bcdsnap.child("CESS").value.toString())
            ADD_CESS.setText(bcdsnap.child("ADD_CESS").value.toString())
            if (bcdsnap.child("SUPPLIERNAME").exists()){
                val suname=bcdsnap.child("SUPPLIERNAME").value.toString()
                SUPPLIERID.setText(suname)
                enterbuttonsupplyer(SUPPLIERID)

            }


         } else {
            NAME.setText("")
            SALES_RATE.setText("")
            STOCK.setText("")
        }
    }

    fun savechanges(view: View?) {
        savebarcode()
    }

    private fun savebarcode() {
        sadapter1?.clear()
        val updatetype: String
        updatetype = if (rb1.isChecked) "weight" else "count"
        if (NAME.text.toString() == "") return
        autoCompleteTextView.append(" ")
        val id = autoCompleteTextView.text.toString().substring(0, autoCompleteTextView.text.toString().indexOf(" "))
        val barcodeMap: MutableMap<String, String> = HashMap()
        barcodeMap["NAME"] = NAME.text.toString()
        barcodeMap["UNIT"] = updatetype
        barcodeMap["STOCK"] = if (STOCK.text.toString() == "") "0" else STOCK.text.toString()
        barcodeMap["SALES_RATE"] = if (SALES_RATE.text.toString() == "") "0" else SALES_RATE.text.toString()
        barcodeMap["MRP"] = if (MRP.text.toString() == "") "0" else MRP.text.toString()
        barcodeMap["PURCHASE_RATE"] = if (PURCHASE_RATE.text.toString() == "") "0" else PURCHASE_RATE.text.toString()
        barcodeMap["GST"] = if (GST.text.toString() == "") "0" else GST.text.toString()
        barcodeMap["CESS"] = if (CESS.text.toString() == "") "0" else CESS.text.toString()
        barcodeMap["ADD_CESS"] = if (ADD_CESS.text.toString() == "") "0" else ADD_CESS.text.toString()
        barcodeMap["SUPPLIERNAME"] = if (SUPPLIERID.text.toString() == "") " " else SUPPLIERID.text.toString()
       FirebaseSupportClass.BCDsnap.child(id).ref.setValue(barcodeMap)

        //((Button) findViewById(R.id.selected_item)).setText("ബാർകോഡ് / പച്ചക്കറി കാണിക്കുക");
        NAME.setText("")
        STOCK.setText("")
        SALES_RATE.setText("")
        PURCHASE_RATE.setText("")
        MRP.setText("")
        GST.setText("")
        NAME.setText("")
        CESS.setText("")
        ADD_CESS.setText("")
        SUPPLIERID.setText("")
        SUPPLIERPHONE.setText("")
        SUPPLYDETAILS.setText("")
        cardpic.setImageBitmap(null)
        sadapter1 = FilterWithSpaceAdapter<String>(this,
                R.layout.item_layout,R.id.tvresid, Support_Functions.barcodeList)
        //Getting the instance of AutoCompleteTextView
        autoCompleteTextView.threshold = 1 //will start working from first character
        autoCompleteTextView.setAdapter(sadapter1) //setting the adapter data into the AutoCompleteTextView
        autoCompleteTextView.setTextColor(Color.RED)
    }

    fun setupUI(view: View) {
        if (view !is EditText) {
            view.setOnTouchListener { v, event ->
                hideSoftKeyboard(this)
                false
            }
        }

        //If a layout container, iterate over children and seed recursion.
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val innerView = view.getChildAt(i)
                setupUI(innerView)
            }
        }
    }

    fun enterbutton(view: View?) {
        autoCompleteTextView.append(" ")
        barcode_scaned(autoCompleteTextView.text.toString().substring(0, endIndex = autoCompleteTextView.text.toString().indexOf(" ")))
        autoCompleteTextView.setText(autoCompleteTextView.text.toString().substring(0, autoCompleteTextView.text.toString().indexOf(" ") + 1))
    }

    fun callsupplyer(view: View?) {
        val uri = "tel:" + SUPPLIERPHONE.text.toString().trim { it <= ' ' }
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse(uri)
        startActivity(intent)
    }


    companion object  {
        fun hideSoftKeyboard(activity: Activity) {
            val inputMethodManager = activity.getSystemService(
                    INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(
                    activity.currentFocus.windowToken, 0)
        }
    }

    fun scanner(view: View) {
        val intent = Intent(this, barcodescanner::class.java)
        startActivity(intent)
    }



    private fun enterbuttonsupplyer(suppliername: AutoCompleteTextView) {
        val name = suppliername.text.toString()
        if (FirebaseSupportClass.Supplyersnapp.child(name).exists()) {
            SUPPLIERPHONE.setText(FirebaseSupportClass.Supplyersnapp.child(name).child("SUPPLIER_PHONE").value.toString())

            SUPPLYDETAILS.setText(FirebaseSupportClass.Supplyersnapp.child(name).child("SUPPLY_DETAILS").value.toString())

            val uid =  FirebaseAuth.getInstance().currentUser!!.uid
            val storageRef = FirebaseStorage.getInstance()!!.reference



            val mImageRef = storageRef?.child(uid + "/SUPPLYER/$name.jpg")
            val ONE_MEGABYTE = (1024 * 1024).toLong()
            mImageRef!!.getBytes(ONE_MEGABYTE)
                    .addOnSuccessListener {
                        val bm = BitmapFactory.decodeByteArray(it, 0, it.size)
                        val dm = DisplayMetrics()
                        windowManager.defaultDisplay.getMetrics(dm)
                        cardpic.minimumHeight = dm.heightPixels
                        cardpic.minimumWidth = dm.widthPixels
                        cardpic.setImageBitmap(bm)

                    }.addOnFailureListener { }


            } else {
            SUPPLIERID.setText("")
            SUPPLIERPHONE.setText("")
            SUPPLYDETAILS.setText("")
        }
    }

    fun newsupplyer(view: View) {
        val i = Intent(this, SupplyerDetails::class.java)
        startActivity(i)
    }

    fun gotopriner(view: View) {


        autoCompleteTextView.append(" ")
        Support_Functions.printbarcode= ( autoCompleteTextView.text.toString().substring(0,
                autoCompleteTextView.text.toString().indexOf(" ")))
        Support_Functions.printname=NAME.text.toString()
        Support_Functions.printCCP=SALES_RATE.text.toString()
        Support_Functions.printMRP=MRP.text.toString()
        savebarcode()
        val i = Intent(this, BarcodePrinting::class.java)
        startActivity(i)
    }
}
