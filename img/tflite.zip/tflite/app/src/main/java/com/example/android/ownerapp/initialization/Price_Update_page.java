package com.example.android.ownerapp.initialization;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.android.ownerapp.R;
import com.example.android.ownerapp.stock_management.Add_IR_Barcode;
import com.example.android.ownerapp.stock_management.IRDBMGR;
import com.example.android.ownerapp.stock_management.Manualentry;
import com.google.firebase.auth.FirebaseAuth;

import static com.example.android.ownerapp.Support_Functions.windowRelatedActions;


public class Price_Update_page extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        windowRelatedActions(this);
        setContentView(R.layout.pricea_update_page);
    }


    public void auto_db_edit(View view) {
        Intent myIntent = new Intent(Price_Update_page.this, Add_IR_Barcode.class);
        Price_Update_page.this.startActivity(myIntent);

    }

    public void ir_DB_Manage(View view) {
        Intent myIntent = new Intent(Price_Update_page.this, IRDBMGR.class);
        Price_Update_page.this.startActivity(myIntent);
    }



    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent myIntent = new Intent(this, login.class);
        this.startActivity(myIntent);
    }

    public void goback(View view) {
        this.onBackPressed();
    }

    public void viewmanualitemspage(View view) {
        Intent intent = new Intent(Price_Update_page.this, Manualentry.class);
        startActivity(intent);
    }
}
