package com.example.android.ownerapp;

import android.app.Activity;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;

import java.util.ArrayList;
import java.util.List;

import static com.example.android.ownerapp.FirebaseSupportClass.BCDsnap;
import static com.example.android.ownerapp.FirebaseSupportClass.IRsnap;
import static com.example.android.ownerapp.FirebaseSupportClass.MANUALsnap;
import static com.example.android.ownerapp.FirebaseSupportClass.Supplyersnapp;

public class Support_Functions {

    public static String barcode = "";
    public static String printbarcode = "";
    public static String printname = "";
    public static String printMRP = "";
    public static String printCCP = "";
    public static String setTagToTextView(TextView tv, String s) {
        String name = s.substring(0, s.indexOf("\n"));
        String price = s.substring((s.indexOf("(") + 1), (s.indexOf("/")));
        String type = s.substring((s.indexOf("/") + 1), (s.indexOf(")")));
        type = (type.equals("piece")) ? "count" : "weight";
        String Mainname_BCD_Manualid = s.substring((s.indexOf(")") + 2));
        String db_name;
        if (s.contains("*")) db_name = tv.getContext().getString(R.string.IR_DB_NAME);
        else {
            if
            (s.contains("%")) db_name = tv.getContext().getString(R.string.BARCODE_DB_NAME);
            else
                db_name = tv.getContext().getString(R.string.MANUAL_DB_NAME);
        }
        tv.setTag(R.id.DB_NAME, db_name);
        tv.setTag(R.id.FIREBASE_PATH, Mainname_BCD_Manualid);
        tv.setTag(R.id.NAME, name);
        tv.setTag(R.id.PRICE, price);
        tv.setTag(R.id.TYPE, type);

        return s.substring(0, s.indexOf(")") + 1);
    }


    public static List<String> generatedArrayList, barcodeList, generatedSupplyerList;
    public static String[] mStringArray, manglisharray;

    public static void generateArrayList() {


        generatedArrayList = new ArrayList<>();
        try {
            if (IRsnap != null && IRsnap.exists()) {
                for (DataSnapshot Main_name : IRsnap.getChildren())
                    for (DataSnapshot Sub_name : Main_name.getChildren()) {
                        if (Sub_name.child("TYPE").exists() && Sub_name.child("PRICE").exists()) {
                            String subname = Sub_name.getKey();
                            String mainname = Main_name.getKey();
                            String type = Sub_name.child("TYPE").getValue().toString();
                            String price = Sub_name.child("PRICE").getValue().toString();
                            if (type.contains("u"))
                                generatedArrayList.add(subname + "\n" + "(" + price + "/piece)*" + mainname + "/" + subname);
                            else
                                generatedArrayList.add(subname + "\n" + "(" + price + "/kg)*" + mainname + "/" + subname);
                        }


                    }

            }

            if (MANUALsnap != null && MANUALsnap.exists()) {
                for (DataSnapshot Item : MANUALsnap.getChildren()) {
                    String id = Item.getKey();
                    String name = Item.child("NAME").getValue().toString();
                    String type = Item.child("TYPE").getValue().toString();
                    String price = Item.child("PRICE").getValue().toString();
                    if (type.contains("u"))
                        generatedArrayList.add(name + "\n" + "(" + price + "/piece)$" + id);
                    else
                        generatedArrayList.add(name + "\n" + "(" + price + "/kg)$" + id);
                }

            }

            if (generatedArrayList.isEmpty()) return;
            else {
                String[] temparray = generatedArrayList.toArray(new String[generatedArrayList.size()]);
                if (!(temparray.length == 0)) {
                    mStringArray = temparray;
                    manglisharray = new String[mStringArray.length];
                    for (int i = 0; i < mStringArray.length; i++) {
                        manglisharray[i] = Ml2En.convert2EN(mStringArray[i]).toLowerCase();
                    }
                }

            }
        } catch (Exception e) {

            final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    new AsyncCallerforGenerateArrayList().execute();
                    //Do something after 100ms
                }
            }, 100);
        }


    }

    public static void genarateBarcodeList() {


        barcodeList = new ArrayList<>();
        try {


            if (BCDsnap != null && BCDsnap.exists()) {
                for (DataSnapshot Item : BCDsnap.getChildren()) {
                    String subname = Item.child("NAME").getValue().toString();
                    ;
                    String bcd = Item.getKey();
                    String type = Item.child("UNIT").getValue().toString();
                    String price = Item.child("SALES_RATE").getValue().toString();
                    barcodeList.add(type.contains("u") ?
                            bcd + " \n" + subname + "\n" + "(" + price + "/piece)" :
                            bcd + " \n" + subname + "\n" + "(" + price + "/kg)");

                }

            }

            if (barcodeList.isEmpty()) return;

        } catch (Exception e) {

            final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    new AsyncCallerforBarcode().execute();
                    //Do something after 100ms
                }
            }, 100);
        }


    }

    public static void genarateSupplyerList() {


        generatedSupplyerList = new ArrayList<>();
        try {
            if (Supplyersnapp != null && Supplyersnapp.exists())
                for (DataSnapshot Supplyer : Supplyersnapp.getChildren())
                { generatedSupplyerList.add(Supplyer.getKey());}

        }catch (Exception e) {

            final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    new AsyncCallerforSupplyer().execute();
                    //Do something after 100ms
                }
            }, 100);
        }
    }

    public static void hideSoftKeyboard(Activity activity, View view) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static void setAppearenceManualItems(TextView tv) {
        tv.setTextColor(Color.WHITE);
        tv.setBackground(tv.getContext().getDrawable(R.drawable.tv_bg_blue));
        tv.setPadding(15, 0, 0, 0);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20);
    }

    public static void windowRelatedActions(Activity activity) {
        activity.requestWindowFeature(Window.FEATURE_NO_TITLE);
        activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = activity.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED, WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);

    }


    public static class AsyncCallerforGenerateArrayList extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //this method will be running on UI thread

        }

        @Override
        protected Void doInBackground(Void... params) {
            generateArrayList();
            //this method will be running on background thread so don't update UI frome here
            //do your long running http tasks here,you dont want to pass argument and u can access the parent class' variable url over here


            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            //this method will be running on UI thread

        }

    }

    public static class AsyncCallerforBarcode extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //this method will be running on UI thread

        }

        @Override
        protected Void doInBackground(Void... params) {
            //generateArrayList();
            genarateBarcodeList();
            //genarate barcode list
            //this method will be running on background thread so don't update UI frome here
            //do your long running http tasks here,you dont want to pass argument and u can access the parent class' variable url over here


            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            //this method will be running on UI thread

        }

    }

    public static class AsyncCallerforSupplyer extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //this method will be running on UI thread

        }

        @Override
        protected Void doInBackground(Void... params) {
            genarateSupplyerList();
             return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            //this method will be running on UI thread

        }

    }
}
