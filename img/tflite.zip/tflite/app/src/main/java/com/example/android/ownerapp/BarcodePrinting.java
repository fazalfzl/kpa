package com.example.android.ownerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import com.example.android.ownerapp.initialization.Setup;
import com.example.android.ownerapp.stock_management.Add_IR_Barcode;
import com.example.tscdll.TSCUSBActivity;

public class BarcodePrinting extends AppCompatActivity {

    TSCUSBActivity TscUSB = new TSCUSBActivity();

    private static final String ACTION_USB_PERMISSION = "com.android.example.USB_PERMISSION";
    private static UsbManager mUsbManager;
    private static PendingIntent mPermissionIntent;
    private static boolean hasPermissionToCommunicate = false;

    private Button test;
    private static UsbDevice device;


    IntentFilter filterAttached_and_Detached = new IntentFilter(UsbManager.ACTION_USB_DEVICE_ATTACHED);
    // Catches intent indicating if the user grants permission to use the USB device
    private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            hasPermissionToCommunicate = true;
                        }
                    }
                }
            }
        }
    };


    EditText pkd, exp;
    final Calendar myCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barcode_printing);


        pkd = findViewById(R.id.pkd);
        exp = findViewById(R.id.exp);

        pkd.setText(new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        exp.setText(new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        pkd.setOnClickListener(this::calanderonClick);
        exp.setOnClickListener(this::calanderonClick);
        Setup.updateshopname();
        ((EditText) findViewById(R.id.shopname)).setText(Setup.shopname);
        mUsbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        mPermissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        registerReceiver(mUsbReceiver, filter);


        UsbAccessory[] accessoryList = mUsbManager.getAccessoryList();
        HashMap<String, UsbDevice> deviceList = mUsbManager.getDeviceList();
        Log.d("Detect ", deviceList.size() + " USB device(s) found");
        Iterator<UsbDevice> deviceIterator = deviceList.values().iterator();
        while (deviceIterator.hasNext()) {
            device = deviceIterator.next();
            if (device.getVendorId() == 4611) {
                //Toast.makeText(MainActivity.this, device.toString(), 0).show();
                break;
            }
        }


        //-----------start-----------
        try {
            PendingIntent mPermissionIntent;
            mPermissionIntent = PendingIntent.getBroadcast(BarcodePrinting.this, 0,
                    new Intent(ACTION_USB_PERMISSION), PendingIntent.FLAG_ONE_SHOT);
            mUsbManager.requestPermission(device, mPermissionIntent);

        } catch (Exception e) {
            Toast.makeText(this, " PRINTER IS NOT CONNECTED , PLEASE RECONNECT", Toast.LENGTH_LONG).show();
        }


    }

    private void updateLabel(EditText edittext) {
        String myFormat = "dd-MM-yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        edittext.setText(sdf.format(myCalendar.getTime()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Support_Functions.printbarcode != null && !Support_Functions.printbarcode.equals(""))
            ((EditText) findViewById(R.id.barcode)).setText(Support_Functions.printbarcode);
        if (Support_Functions.printname != null && !Support_Functions.printname.equals(""))
            ((EditText) findViewById(R.id.itemname)).setText(Support_Functions.printname);
        if (Support_Functions.printMRP != null && !Support_Functions.printMRP.equals(""))
            ((EditText) findViewById(R.id.mrp)).setText(Support_Functions.printMRP);
        if (Support_Functions.printCCP != null && !Support_Functions.printCCP.equals(""))
            ((EditText) findViewById(R.id.ccp)).setText(Support_Functions.printCCP);
    }


    private void addEXPToPrinter(String s) {
        if (s.length() > 30) s = s.substring(0, 29);
        TscUSB.sendcommand("TEXT 270,175,\"0\",270,6,6,\"EXP:" + s + "\"\r\n");
        TscUSB.sendcommand("TEXT 595,175,\"0\",270,6,6,\"EXP:" + s + "\"\r\n");
    }

    private void addPKDToPrinter(String s) {
        if (s.length() > 30) s = s.substring(0, 29);
        TscUSB.sendcommand("TEXT 250,175,\"0\",270,6,6,\"PKD:" + s + "\"\r\n");
        TscUSB.sendcommand("TEXT 580,175,\"0\",270,6,6,\"PKD:" + s + "\"\r\n");
    }

    private void addCCPToPrinter(String s) {
        if (s.length() > 30) s = s.substring(0, 29);
        TscUSB.sendcommand("TEXT 8,175,\"0\",0,8,9,\"CCP:" + s + "\"\r\n");
        TscUSB.sendcommand("TEXT 340,175,\"0\",0,8,9,\"CCP:" + s + "\"\r\n");
    }

    private void addMRPToPrinter(String s) {
        if (s.length() > 30) s = s.substring(0, 29);
        TscUSB.sendcommand("TEXT 8,150,\"0\",0,8,9,\"MRP:" + s + "\"\r\n");
        TscUSB.sendcommand("TEXT 340,150,\"0\",0,8,9,\"MRP:" + s + "\"\r\n");
    }

    private void addItemNameToPrinter(String s) {
        if (s.length() > 30) s = s.substring(0, 29);
        TscUSB.sendcommand("TEXT 8,125,\"0\",0,8,9,\"" + s + "\"\r\n");
        TscUSB.sendcommand("TEXT 340,125,\"0\",0,8,9,\"" + s + "\"\r\n");
    }

    private void addShopNameToPrinter(String s) {
        if (s.length() > 30) s = s.substring(0, 29);
        TscUSB.sendcommand("TEXT 8,20,\"0\",0,8,9,\"" + s + "\"\r\n");
        TscUSB.sendcommand("TEXT 340,20,\"0\",0,8,9,\"" + s + "\"\r\n");
    }

    private void addBarcodeToPrinter(String s) {
        TscUSB.sendcommand("BARCODE 20,50, \"128\",50,2,0,2,2,\"" + s + "\"\r\n");
        TscUSB.sendcommand("BARCODE 360,50, \"128\",50,2,0,2,2,\"" + s + "\"\r\n");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    public void testprint(View view) {
        Setup.shopnameREF.setValue(((EditText) findViewById(R.id.shopname)).getText().toString());

        if (mUsbManager.hasPermission(device)) {
            TscUSB.openport(mUsbManager, device);

            TscUSB.sendcommand("SIZE 3,1\r\n");
            TscUSB.sendcommand("GAP 0.12,0\r\n");
            TscUSB.sendcommand("CLS\r\n");

            addShopNameToPrinter(((EditText) findViewById(R.id.shopname)).getText().toString());

            addBarcodeToPrinter(((EditText) findViewById(R.id.barcode)).getText().toString());

            addItemNameToPrinter(((EditText) findViewById(R.id.itemname)).getText().toString());

            addMRPToPrinter(((EditText) findViewById(R.id.mrp)).getText().toString());
            addCCPToPrinter(((EditText) findViewById(R.id.ccp)).getText().toString());

            addPKDToPrinter(((EditText) findViewById(R.id.pkd)).getText().toString());
            addEXPToPrinter(((EditText) findViewById(R.id.exp)).getText().toString());

            TscUSB.sendcommand("PRINT 1\r\n");
            TscUSB.closeport(3000);


        }

    }

    public void bulkPrint(View view) {
        Setup.shopnameREF.setValue(((EditText) findViewById(R.id.shopname)).getText().toString());

        if (mUsbManager.hasPermission(device)) {
            TscUSB.openport(mUsbManager, device);

            TscUSB.sendcommand("SIZE 3,1\r\n");
            TscUSB.sendcommand("GAP 0.12,0\r\n");
            TscUSB.sendcommand("CLS\r\n");

            addShopNameToPrinter(((EditText) findViewById(R.id.shopname)).getText().toString());

            addBarcodeToPrinter(((EditText) findViewById(R.id.barcode)).getText().toString());

            addItemNameToPrinter(((EditText) findViewById(R.id.itemname)).getText().toString());

            addMRPToPrinter(((EditText) findViewById(R.id.mrp)).getText().toString());
            addCCPToPrinter(((EditText) findViewById(R.id.ccp)).getText().toString());

            addPKDToPrinter(((EditText) findViewById(R.id.pkd)).getText().toString());
            addEXPToPrinter(((EditText) findViewById(R.id.exp)).getText().toString());


            TscUSB.sendcommand("PRINT " + Integer.parseInt((((EditText) findViewById(R.id.bulkprintcount)).getText().toString())) + "\r\n");
            TscUSB.closeport(3000);


        }

    }

    public void selectbarcode(View view) {
        Intent i = new Intent(this, Add_IR_Barcode.class);
        startActivity(i);
    }

    private void calanderonClick(View v) {
        // TODO Auto-generated method stub
        new DatePickerDialog(BarcodePrinting.this, (view, year, monthOfYear, dayOfMonth) -> {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            BarcodePrinting.this.updateLabel((EditText) v);
        }, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    Calendar c = Calendar.getInstance();

    public void addday(View view) {
        try {
            c.setTime(sdf.parse(exp.getText().toString()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DAY_OF_MONTH, 1);
        String newDate = sdf.format(c.getTime());
        exp.setText(newDate);
        showdiff();
    }

    public void addweek(View view) {
        try {
            c.setTime(sdf.parse(exp.getText().toString()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DAY_OF_MONTH, 7);
        String newDate = sdf.format(c.getTime());
        exp.setText(newDate);
        showdiff();
    }

    public void addmonth(View view) {
        try {
            c.setTime(sdf.parse(exp.getText().toString()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.DAY_OF_MONTH, 30);
        String newDate = sdf.format(c.getTime());
        exp.setText(newDate);
        showdiff();
    }

    public void reset(View view) {
        exp.setText(new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()));
        ((Button) view).setText("RESET");
    }

    private void showdiff() {
        String inputString1 = pkd.getText().toString();
        String inputString2 = exp.getText().toString();

        try {
            Date date1 = sdf.parse(inputString1);
            Date date2 = sdf.parse(inputString2);
            long diff = date2.getTime() - date1.getTime();

            String d = "" + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
            ((Button) findViewById(R.id.reset)).setText("Reset \n" + d + " Days");
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }


}