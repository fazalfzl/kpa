package com.example.android.ownerapp.stock_management;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.android.ownerapp.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

import static com.example.android.ownerapp.Support_Functions.windowRelatedActions;
import static com.example.android.ownerapp.FirebaseSupportClass.IRsnap;

public class IRDBMGR extends Activity implements View.OnClickListener {

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                activity.getCurrentFocus().getWindowToken(), 0);
    }
    FirebaseStorage storage ;
    StorageReference storageRef ;
    public void resize_and_putBackground(Button imageView,Bitmap bmp){
        int imgHeight = bmp.getHeight();
        int imgWidth = bmp.getWidth();
        int containerHeight = imageView.getHeight();
        int containerWidth = imageView.getWidth();
        boolean ch2cw = containerHeight > containerWidth;
        float h2w = (float) imgHeight / (float) imgWidth;
        float newContainerHeight, newContainerWidth;

        if (h2w > 1) {
            // height is greater than width
            if (ch2cw) {
                newContainerWidth = (float) containerWidth;
                newContainerHeight = newContainerWidth * h2w;
            } else {
                newContainerHeight = (float) containerHeight;
                newContainerWidth = newContainerHeight / h2w;
            }
        } else {
            // width is greater than height
            if (ch2cw) {
                newContainerWidth = (float) containerWidth;
                newContainerHeight = newContainerWidth / h2w;
            } else {
                newContainerWidth = (float) containerHeight;
                newContainerHeight = newContainerWidth * h2w;
            }
        }
        Bitmap copy = Bitmap.createScaledBitmap(bmp, (int) newContainerWidth, (int) newContainerHeight, false);
        imageView.setBackgroundDrawable(new BitmapDrawable(copy));
        TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
        imageView.setLayoutParams(params);
        imageView.setMaxHeight((int) newContainerHeight);
        imageView.setMaxWidth((int) newContainerWidth);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        windowRelatedActions(this);

        setContentView(R.layout.ir_db_manuall);
        setupUI(findViewById(R.id.rlll));
        storage=FirebaseStorage.getInstance();
        storageRef = storage.getReference();



        findViewById(R.id.rlll).postDelayed(new Runnable() {
            @Override
            public void run() {
                //replace this line to scroll up or down
                hideSoftKeyboard(IRDBMGR.this);
            }
        }, 1000);

        name1 = findViewById(R.id.name1);
        name2 = findViewById(R.id.name2);
        name3 = findViewById(R.id.name3);
        price1 = findViewById(R.id.price1);
        price2 = findViewById(R.id.price2);
        price3 = findViewById(R.id.price3);
        stock1 = findViewById(R.id.stock1);
        stock2 = findViewById(R.id.stock2);
        stock3 = findViewById(R.id.stock3);

        show_RECODB();


    }
    EditText name1,name2,name3,price1,price2,price3,stock1,stock2,stock3;

    public void show_RECODB() {

        findViewById(R.id.subnames_table).setTag("");
        name1.setText("");
        name2.setText("");
        name3.setText("");
        price1.setText("");
        price2.setText("");
        price3.setText("");
        stock1.setText("");
        stock2.setText("");
        stock3.setText("");

        TableLayout stk = findViewById(R.id.tablelayout);

        stk.removeAllViews();
        int i = 0;
        for (DataSnapshot mainSnap : IRsnap.getChildren()) {
             TableRow tbrow = new TableRow(this);

            Button firstbuttonforImage = new Button(this);
            firstbuttonforImage.setGravity(Gravity.CENTER);
            tbrow.addView(firstbuttonforImage);

            firstbuttonforImage.setLayoutParams(new TableRow.LayoutParams(160, 160));

            StorageReference islandRef  = storageRef.child("images/"+mainSnap.getKey()+".bmp");
            final long ONE_MEGABYTE = 1024 * 1024;
            islandRef.getBytes(ONE_MEGABYTE).addOnSuccessListener((OnSuccessListener<byte[]>) bytes -> {
                Bitmap bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                resize_and_putBackground(firstbuttonforImage,bm);
            }).addOnFailureListener(exception -> { });



            firstbuttonforImage.setOnClickListener(this);

            TextView t2v = new TextView(this);
            t2v.setText(mainSnap.getKey());
            t2v.setHeight(200);
            t2v.setTextColor(Color.WHITE);
            t2v.setGravity(Gravity.CENTER);
            t2v.setOnClickListener(this);
            tbrow.addView(t2v);


            String subnames = "";
            for (DataSnapshot subSnap : mainSnap.getChildren()) {
                subnames += subSnap.getKey() + "\n";
            }

            subnames = subnames.substring(0, subnames.length() - 1);
            TextView t3v = new TextView(this);
            t3v.setText(subnames);
            t3v.setTextColor(Color.WHITE);
            t3v.setGravity(Gravity.CENTER);
            t3v.setOnClickListener(this);
            tbrow.addView(t3v);


            if (i% 2 == 0)
                tbrow.setBackgroundColor(Color.GRAY);
            else
                tbrow.setBackgroundColor(Color.BLUE);

            tbrow.setGravity(Gravity.CENTER_VERTICAL);
            tbrow.setOnClickListener(view -> t3v.callOnClick());
            stk.addView(tbrow);
            i++;
        }


    }

    public void savechanges(View view) {



        String Mainname = findViewById(R.id.subnames_table).getTag().toString();
        if (!name1.getText().toString().equals("") || !name2.getText().toString().equals("") || !name3.getText().toString().equals("")) {
            IRsnap.child(Mainname).getRef().setValue(null).addOnCompleteListener(task1 -> {
                if (!name1.getText().toString().equals("")) {
                    Map<String, String> subNameMap = new HashMap<>();
                    subNameMap.put("TYPE", (((RadioButton) findViewById(R.id.rb2)).isChecked()) ? "count" : "weight");
                    subNameMap.put("PRICE", (price1.getText().toString().equals("")) ? "0" : price1.getText().toString());
                    subNameMap.put("STOCK", (stock1.getText().toString().equals("")) ? "0" : stock1.getText().toString());
                    IRsnap.child(Mainname).child(name1.getText().toString()).getRef().setValue(subNameMap).addOnCompleteListener(task -> show_RECODB());
                }

                if (!name2.getText().toString().equals("")) {
                    Map<String, String> subNameMap = new HashMap<>();
                    subNameMap.put("TYPE", (((RadioButton) findViewById(R.id.rb4)).isChecked()) ? "count" : "weight");
                    subNameMap.put("PRICE", (price2.getText().toString().equals("")) ? "0" : price2.getText().toString());
                    subNameMap.put("STOCK", (stock2.getText().toString().equals("")) ? "0" : stock2.getText().toString());
                    IRsnap.child(Mainname).child(name2.getText().toString()).getRef().setValue(subNameMap).addOnCompleteListener(task -> show_RECODB());
                }

                if (!name3.getText().toString().equals("")) {
                    Map<String, String> subNameMap = new HashMap<>();
                    subNameMap.put("TYPE", (((RadioButton) findViewById(R.id.rb6)).isChecked()) ? "count" : "weight");
                    subNameMap.put("PRICE", (price3.getText().toString().equals("")) ? "0" : price3.getText().toString());
                    subNameMap.put("STOCK", (stock3.getText().toString().equals("")) ? "0" : stock3.getText().toString());
                    IRsnap.child(Mainname).child(name3.getText().toString()).getRef().setValue(subNameMap).addOnCompleteListener(task -> show_RECODB());
                }

            });
        }




    }


    @Override
    public void onClick(View view) {

        name1.setText("");
        name2.setText("");
        name3.setText("");
        price1.setText("");
        price2.setText("");
        price3.setText("");

        hideSoftKeyboard(this);
        TableRow tr = (TableRow) view.getParent();
        TextView tv = (TextView) tr.getChildAt(1);
        findViewById(R.id.subnames_table).setTag(tv.getText().toString());


        int i = 0;
        for (DataSnapshot subSnap : IRsnap.child(tv.getText().toString()).getChildren())
        {
            TableRow row = (TableRow) ((TableLayout) findViewById(R.id.subnames_table)).getChildAt(i);
            i++;
            ((EditText) row.getChildAt(0)).setText
                    (subSnap.getKey());
            ((EditText) row.getChildAt(1)).setText(
                    subSnap.child("PRICE").getValue().toString());
            if (subSnap.child("TYPE").getValue().toString().equals("weight")) {
                ((RadioButton) ((RadioGroup) row.getChildAt(2)).getChildAt(0)).setChecked(true);
            } else {
                ((RadioButton) ((RadioGroup) row.getChildAt(2)).getChildAt(1)).setChecked(true);
            }

            ((EditText) row.getChildAt(3)).setText(
                    subSnap.child("STOCK").getValue().toString());
        }
    }

    public void setupUI(View view) {
        // Set up touch listener for non-text box views to hide keyboard.
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(IRDBMGR.this);
                    return false;
                }
            });
        }

        //If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView);
            }
        }
    }

}
