package com.example.android.ownerapp.stock_management

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.android.ownerapp.FirebaseSupportClass.Supplyersnapp
import com.example.android.ownerapp.R
import com.example.android.ownerapp.Support_Functions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.android.synthetic.main.supplyer_details.*
import java.io.ByteArrayOutputStream
import java.util.*


class SupplyerDetails : AppCompatActivity() {
    private val CAMERA_REQUEST = 1888
    var storage: FirebaseStorage? = null
    var storageRef: StorageReference? = null
    private val MY_CAMERA_PERMISSION_CODE = 100
    var adapter: ArrayAdapter<String>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.supplyer_details)

        adapter = ArrayAdapter(this, android.R.layout.select_dialog_item, Support_Functions.generatedSupplyerList)
        SUPPLIERID.threshold = 1
        SUPPLIERID.setAdapter(adapter) //setting the adapter data into the AutoCompleteTextView
        SUPPLIERID.setTextColor(Color.RED)


        SUPPLIERID.onItemClickListener = AdapterView.OnItemClickListener { parent: AdapterView<*>?, arg1: View?, pos: Int, id: Long ->
            //  Toast.makeText(check.this," selected", Toast.LENGTH_LONG).show();
            enterbutton(SUPPLIERID)
        }

        storage = FirebaseStorage.getInstance()
        storageRef = storage!!.reference

    }

    private fun enterbutton(suppliername: AutoCompleteTextView) {
        val name = suppliername.text.toString()
        if (Supplyersnapp.child(name).exists()) {

            val uid =  FirebaseAuth.getInstance().currentUser!!.uid
            val database = FirebaseDatabase.getInstance()
            storageRef = FirebaseStorage.getInstance()!!.reference



            val mImageRef = storageRef?.child(uid + "/SUPPLYER/$name.jpg")
            val ONE_MEGABYTE = (1024 * 1024).toLong()
            mImageRef!!.getBytes(ONE_MEGABYTE)
                    .addOnSuccessListener {
                        val bm = BitmapFactory.decodeByteArray(it, 0, it.size)
                        val dm = DisplayMetrics()
                        windowManager.defaultDisplay.getMetrics(dm)
                        cardpic.minimumHeight = dm.heightPixels
                        cardpic.minimumWidth = dm.widthPixels
                        cardpic.setImageBitmap(bm)

                    }.addOnFailureListener { }


            SUPPLIERPHONE.setText(Supplyersnapp.child(name).child("SUPPLIER_PHONE").value.toString())
            SUPPLYDETAILS.setText(Supplyersnapp.child(name).child("SUPPLY_DETAILS").value.toString())
        } else {
            SUPPLIERID.setText("")
            SUPPLIERPHONE.setText("")
            SUPPLYDETAILS.setText("")
        }
    }

    fun callsupplyer(view: View) {
        val uri = "tel:" + SUPPLIERPHONE.text.toString().trim { it <= ' ' }
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse(uri)
        startActivity(intent)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    fun takesupplyerpic(view: View) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), MY_CAMERA_PERMISSION_CODE)
        } else {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(cameraIntent, CAMERA_REQUEST)
        }
    }

    fun savesupplyer(view: View) {
        val mAuth = FirebaseAuth.getInstance()
        val user = mAuth.currentUser
        val uid = user!!.uid
        val database = FirebaseDatabase.getInstance()

//        adapter?.clear()
        if (SUPPLIERID.text.toString().isEmpty()) return
        val SupplyerMap: MutableMap<String, String> = HashMap()
        SupplyerMap["SUPPLIER_PHONE"] = if (SUPPLIERPHONE.text.toString() == "") " " else SUPPLIERPHONE.text.toString()
        SupplyerMap["SUPPLY_DETAILS"] = if (SUPPLYDETAILS.text.toString() == "") " " else SUPPLYDETAILS.text.toString()
        database.getReference(uid + "/SUPPLYER").child(SUPPLIERID.text.toString()).setValue(SupplyerMap)
        val name=SUPPLIERID.text.toString()
        SUPPLIERID.setText("")
        SUPPLIERPHONE.setText("")
        SUPPLYDETAILS.setText("")
        adapter = ArrayAdapter(this, android.R.layout.select_dialog_item, Support_Functions.generatedSupplyerList)
        SUPPLIERID.threshold = 1
        SUPPLIERID.setAdapter(adapter)
        SUPPLIERID.setTextColor(Color.RED)


        val baos = ByteArrayOutputStream()
        photo?.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data: ByteArray = baos.toByteArray()

        storageRef?.child(uid + "/SUPPLYER/$name.jpg")?.putBytes(data)?.addOnFailureListener {
            // Handle unsuccessful uploads
        }?.addOnSuccessListener { taskSnapshot -> // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
            cardpic.setImageBitmap(null)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String?>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show()
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivityForResult(cameraIntent, CAMERA_REQUEST)
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show()
            }
        }
    }
var photo:Bitmap?=null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            photo = data?.extras?.get("data") as Bitmap
            cardpic!!.setImageBitmap(photo)
        }
        super.onActivityResult(requestCode, resultCode, data)
    }



}