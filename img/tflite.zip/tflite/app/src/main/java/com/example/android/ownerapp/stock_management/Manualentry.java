package com.example.android.ownerapp.stock_management;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.android.ownerapp.Ml2En;
import com.example.android.ownerapp.R;

import java.util.HashMap;
import java.util.Map;

import static com.example.android.ownerapp.Support_Functions.hideSoftKeyboard;
import static com.example.android.ownerapp.Support_Functions.mStringArray;
import static com.example.android.ownerapp.Support_Functions.manglisharray;
import static com.example.android.ownerapp.Support_Functions.setAppearenceManualItems;
import static com.example.android.ownerapp.Support_Functions.setTagToTextView;
import static com.example.android.ownerapp.Support_Functions.windowRelatedActions;
import static com.example.android.ownerapp.FirebaseSupportClass.MANUALsnap;

public class Manualentry extends AppCompatActivity {
    View.OnClickListener textonclicklistener;
    TableLayout manualentryTLO;
    TableRow.LayoutParams params;
    EditText ed_name, ed_price, ed_stock;
    RadioButton rb1w, rb2c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        windowRelatedActions(this);
        setContentView(R.layout.manual_entry);

        manualentryTLO = findViewById(R.id.tab_manual_options);
        ed_name = findViewById(R.id.name);
        ed_price = findViewById(R.id.price);
        ed_stock = findViewById(R.id.stock);
        rb1w = findViewById(R.id.rb1);
        rb2c = findViewById(R.id.rb2);

        textonclicklistener = view -> {

            findViewById(R.id.update).setEnabled(true);
            findViewById(R.id.delete).setEnabled(true);
            findViewById(R.id.rel_for_manual_entry).setVisibility(View.GONE);

            String RandomKey = (String) view.getTag(R.id.FIREBASE_PATH);

            String name = (String) view.getTag(R.id.NAME);
            String price = (String) view.getTag(R.id.PRICE);
            String type = (String) view.getTag(R.id.TYPE);
            ed_name.setTag(R.id.FIREBASE_PATH, RandomKey);


            ed_name.setText(name);
            ed_name.setTag(RandomKey);
            ((Button) findViewById(R.id.update)).setText("UPDATE\n" + name);


            ed_price.setText("" + price);
            ed_stock.setText("" + MANUALsnap.child(RandomKey).child("STOCK").getValue().toString());
            //touched on a item that billby weight
            if (type.equals("weight")) {
                rb1w.setChecked(true);
            } else //touched on a item that billby count
            {
                rb2c.setChecked(true);

            }


        };


    }


    private void showItemsContaining() {

        findViewById(R.id.rel_for_manual_entry).setVisibility(View.VISIBLE);
        params = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT);
        params.setMargins(5, 5, 5, 5);


        ((EditText) findViewById(R.id.edt_manual_entry)).setText("");

        while (manualentryTLO.getChildCount() > 0) {
            manualentryTLO.removeViewAt((manualentryTLO.getChildCount() - 1));
        }

        TableRow tr = new TableRow(this);

        for (String s : mStringArray) {
            if (!s.contains("$")) continue;
            TextView tv = (TextView) new TextView(this);
            tv.setText(setTagToTextView(tv, s));
            tv.setOnClickListener(textonclicklistener);


            setAppearenceManualItems(tv);


            tr.addView(tv, params);
            if (tr.getChildCount() == 3) {
                manualentryTLO.addView(tr);
                tr = new TableRow(this);
            }
        }
        manualentryTLO.addView(tr);
        tr = new TableRow(this);
        TextView tv = (TextView) new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 50);
        tv.setText("!!!");
        tr.addView(tv);
        manualentryTLO.addView(tr);


        EditText editText = findViewById(R.id.edt_manual_entry);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                while (manualentryTLO.getChildCount() > 0) {
                    manualentryTLO.removeViewAt((manualentryTLO.getChildCount() - 1));
                }

                String keyword = editText.getText().toString();
                keyword = Ml2En.convert2EN(keyword).toLowerCase();
                TableRow tr = new TableRow(Manualentry.this);

                for (int i = 0; i < mStringArray.length; i++) {
                    String s = manglisharray[i];
                    if (s.contains(keyword) && s.contains("$")) {


                        TextView tv = (TextView) new TextView(Manualentry.this);
                        tv.setText(setTagToTextView(tv, mStringArray[i]));
                        tv.setOnClickListener(textonclicklistener);

                        setAppearenceManualItems(tv);

                        tr.addView(tv, params);
                        if (tr.getChildCount() == 3) {
                            manualentryTLO.addView(tr);
                            tr = new TableRow(Manualentry.this);
                        }
                    }


                }
                manualentryTLO.addView(tr);
                tr = new TableRow(Manualentry.this);
                TextView tv = (TextView) new TextView(Manualentry.this);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 50);
                tv.setText("!!!");
                tr.addView(tv);
                manualentryTLO.addView(tr);
            }
        });


    }


    public void updateexisting(View view)  {
        try{

            showItemsContaining();
        }catch (Exception e){updateexisting(view);}
        ed_name.setText("");
        ed_price.setText("");
        ed_stock.setText("");
    }

    public void closeManualEntry(View view) {

        hideSoftKeyboard(this, view);
        ((EditText) findViewById(R.id.edt_manual_entry)).setText("");
        findViewById(R.id.rel_for_manual_entry).setVisibility(View.GONE);
        view.setVisibility(View.GONE);
    }


    public void save(View view) {
        String name = ed_name.getText().toString();
        String price = ed_price.getText().toString();
        String stock = ed_stock.getText().toString();
        String type = (rb1w.isChecked()) ? "weight" : "count";
        stock = (stock.equals("")) ? "0" : stock;

        if (name.equals("") || price.equals("")) return;

        Map<String, String> billMap = new HashMap<>();
        billMap.put("NAME", name);
        billMap.put("PRICE", price);
        billMap.put("TYPE", type);
        billMap.put("STOCK", stock);
        MANUALsnap.getRef().push().setValue(billMap);


        hideSoftKeyboard(this, view);
        ed_price.setText("");
        ed_name.setText("");
        ed_stock.setText("");
        findViewById(R.id.update).setEnabled(false);
        findViewById(R.id.delete).setEnabled(false);

        Toast.makeText(this, name + "(" + price + ") saved", Toast.LENGTH_LONG).show();
    }

    public void update(View view) {

        hideSoftKeyboard(this, view);
        String key = ed_name.getTag(R.id.FIREBASE_PATH).toString();

        String type = (rb1w.isChecked()) ? "weight" : "count";


        Map<String, String> billMap = new HashMap<>();
        billMap.put("NAME", ed_name.getText().toString());
        billMap.put("TYPE", type);
        billMap.put("PRICE", ed_price.getText().toString());
        billMap.put("STOCK", ed_stock.getText().toString());
        MANUALsnap.child(key).getRef().setValue(billMap);
        Toast.makeText(this, "updated to " + ed_name.getText().toString(), Toast.LENGTH_LONG).show();
        ((Button) findViewById(R.id.update)).setText("UPDATE");

        ed_name.setText("");
        ed_price.setText("");
        ed_stock.setText("");
        findViewById(R.id.update).setEnabled(false);
        findViewById(R.id.delete).setEnabled(false);
     }

    public void delete(View view) {
        hideSoftKeyboard(this, view);
        String key = ed_name.getTag(R.id.FIREBASE_PATH).toString();

        DialogInterface.OnClickListener dialogClickListener = (dialog, which) -> {
            switch (which) {
                case DialogInterface.BUTTON_POSITIVE:
                    MANUALsnap.child(key).getRef().removeValue();
                    ed_name.setText("");
                    ed_price.setText("");
                    ed_stock.setText("");
                    findViewById(R.id.update).setEnabled(false);
                    findViewById(R.id.delete).setEnabled(false);
                    //Yes button clicked
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    //No button clicked
                    break;
            }

            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(MANUALsnap.child(key).child("NAME").getValue().toString() +
                "മുഴുവനായി കളയണോ ?").setPositiveButton("വേണം\nyes", dialogClickListener)
                .setNegativeButton("വേണ്ട\nno", dialogClickListener).show();


        //


    }

    public void clickedonparent(View view) {
        closeManualEntry(findViewById(R.id.close_manual_entry));
    }
}