package com.example.android.ownerapp.initialization;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.android.ownerapp.BarcodePrinting;
import com.example.android.ownerapp.R;
import com.example.android.ownerapp.Support_Functions;
import com.example.android.ownerapp.FirebaseSupportClass;
import com.example.android.ownerapp.billview;
import com.example.android.ownerapp.stock_management.SupplyerDetails;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static com.example.android.ownerapp.Support_Functions.windowRelatedActions;

public class Setup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {

            FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        } catch (Exception e) {
        }

        FirebaseSupportClass.setup = Setup.this;

        windowRelatedActions(this);

        setContentView(R.layout.setup);

    }

    @Override
    protected void onResume() {

        initialiseFirebaseDb();

        new Support_Functions.AsyncCallerforGenerateArrayList().execute();


        super.onResume();
    }


    public static FirebaseDatabase database;
    public static DatabaseReference fbREFir, fbREFbcd, fbREFm, fbREFsupplyer,shopnameREF;
    public static String uid,shopname="shopname";


    private void initialiseFirebaseDb() {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        uid = user.getUid();
        database = FirebaseDatabase.getInstance();
        fbREFsupplyer = database.getReference(uid + "/SUPPLYER");
        fbREFsupplyer.addValueEventListener(FirebaseSupportClass.supplyersync);
        fbREFir = database.getReference(uid + "/IR");
        fbREFir.addValueEventListener(FirebaseSupportClass.irsync);
        fbREFbcd = database.getReference(uid + "/BARCODE");
        fbREFbcd.addValueEventListener(FirebaseSupportClass.bcdsync);
        fbREFm = database.getReference(uid + "/MANUAL");
        fbREFm.addValueEventListener(FirebaseSupportClass.msync);

        updateshopname();


        database.getReference(uid).keepSynced(true);
    }

    public static void updateshopname() {

        shopnameREF=database.getReference(uid + "/shopname");
        shopnameREF.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                shopname = snapshot.getValue(String.class);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


    public void gotopriceupdatepage(View view) {
        Intent i = new Intent(this, Price_Update_page.class);
        startActivity(i);
    }

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent myIntent = new Intent(this, login.class);
        this.startActivity(myIntent);
    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, login.class);
        startActivity(intent);
    }

    public void viewBills(View view) {
        Intent i = new Intent(this, billview.class);
        startActivity(i);
    }

    public void view_supplyer(View view) {
        Intent i = new Intent(this, SupplyerDetails.class);
        startActivity(i);
    }

    public void print_barcode(View view) {
        Intent i = new Intent(this, BarcodePrinting.class);
        startActivity(i);
    }
}