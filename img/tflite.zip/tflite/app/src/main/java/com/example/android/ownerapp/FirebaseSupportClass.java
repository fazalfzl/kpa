package com.example.android.ownerapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.android.ownerapp.initialization.Setup;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FirebaseSupportClass {
    public static DataSnapshot IRsnap, BCDsnap, MANUALsnap, Supplyersnapp;
    public static Setup setup;
    public static ValueEventListener irsync = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot IR) {
            IRsnap = IR;
            new Support_Functions.AsyncCallerforGenerateArrayList().execute();
        }

        @Override
        public void onCancelled(DatabaseError error) {
            // Failed to read value
        }
    };
    public static ValueEventListener bcdsync = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot IR) {
            BCDsnap = IR;
            new Support_Functions.AsyncCallerforBarcode().execute();
        }

        @Override
        public void onCancelled(DatabaseError error) {
            // Failed to read value
        }
    };
    public static ValueEventListener msync = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot IR) {
            MANUALsnap = IR;
            new Support_Functions.AsyncCallerforGenerateArrayList().execute();
        }

        @Override
        public void onCancelled(DatabaseError error) {
            // Failed to read value
        }
    };
    public static ValueEventListener supplyersync = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot IR) {
            Supplyersnapp = IR;
             new Support_Functions.AsyncCallerforSupplyer().execute();
        }

        @Override
        public void onCancelled(DatabaseError error) {
            // Failed to read value
        }
    };


}
