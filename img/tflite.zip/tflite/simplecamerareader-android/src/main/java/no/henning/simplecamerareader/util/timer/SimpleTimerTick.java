package no.henning.simplecamerareader.util.timer;

public interface SimpleTimerTick
{
	public void onTick();
}